# FaceCore Vision Console

A professional dashboard for the FaceCore face-analysis library: detect faces,
analyze age/gender/emotion, compare two faces, run a lightweight recognition
gallery, and face-swap — all through a Flask API and a dark, instrument-panel
style HTML/CSS/JS frontend.

## Structure

```
facecore_dashboard/
├── app.py                 # Flask backend (all API routes)
├── requirements.txt
├── FaceCore/               # the FaceCore library (detector, analyzer, etc.)
├── templates/
│   └── index.html
├── static/
│   ├── css/style.css
│   └── js/app.js
├── uploads/                # generated result/preview images (created at runtime)
└── gallery/                # reserved for persisted gallery data
```

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

FaceCore itself needs two more things to do live inference:

1. **insightface model pack** — downloaded automatically on first run to
   `~/.insightface/models/buffalo_l` (needs internet access the first time).
2. **Face swap model** (optional, only for the Swap tab) — place
   `inswapper_128.onnx` at `~/.insightface/models/inswapper_128.onnx`.
3. **Emotion model** (optional, for emotion scores in Analyze) — place
   `emotion-ferplus-8.onnx` at `~/.easyface/models/emotion-ferplus-8.onnx`.

If these aren't present, the dashboard still runs — every endpoint returns a
clear "engine unavailable" message instead of crashing, and the sidebar status
light shows the real state.

## Run

```bash
python app.py
```

Then open **http://localhost:5000**.

## API summary

| Route                         | Method | Purpose                                  |
|--------------------------------|--------|-------------------------------------------|
| `/api/status`                  | GET    | Engine readiness check                     |
| `/api/detect`                  | POST   | Face detection (`image`)                   |
| `/api/analyze`                 | POST   | Age/gender/emotion (`image`, `emotion`)    |
| `/api/compare`                 | POST   | Similarity score (`image_a`, `image_b`)    |
| `/api/gallery`                 | GET    | List registered names                      |
| `/api/gallery/register`        | POST   | Register a person (`name`, `image`)        |
| `/api/gallery/recognize`       | POST   | Identify a face against the gallery        |
| `/api/swap`                    | POST   | Face swap (`source`, `target`)             |

All responses are JSON; image results are returned as `/uploads/<file>` URLs.
