"""
Face swapping — wraps insightface's inswapper model.

Requires the inswapper_128.onnx model file. easyface will look for it
at ~/.insightface/models/inswapper_128.onnx by default (the standard
insightface cache location); download it separately since it is not
bundled with this package.
"""

import os
from .utils import load_image_rgb, to_bgr, to_rgb, save_image

try:
    import insightface
except ImportError:
    insightface = None


DEFAULT_SWAPPER_PATH = os.path.expanduser("~/.insightface/models/inswapper_128.onnx")


class Swapper:
    def __init__(self, detector, model_path=None):
        self._detector = detector
        self._model_path = model_path or DEFAULT_SWAPPER_PATH
        self._model = None

    def _load_model(self):
        if self._model is not None:
            return self._model

        if insightface is None:
            raise ImportError("insightface is required for face swapping. Install with: pip install insightface")

        if not os.path.exists(self._model_path):
            raise FileNotFoundError(
                f"Swap model not found at {self._model_path}. "
                "Download 'inswapper_128.onnx' and place it there, or pass model_path=Face(swap_model='...')"
            )

        # insightface.model_zoo.get_model() auto-detects the wrapper class by
        # inspecting the ONNX graph's output names. That detection is version-
        # fragile for inswapper_128.onnx specifically: on some onnx/onnxruntime
        # combinations it fails to recognize the model and falls back to
        # returning the bare onnxruntime.InferenceSession, which has no .get()
        # method (that's what "'InferenceSession' object has no attribute
        # 'get'" means). Building INSwapper directly sidesteps that detection
        # entirely and always returns the real wrapper.
        try:
            from insightface.model_zoo.inswapper import INSwapper
            self._model = INSwapper(model_file=self._model_path)
        except Exception:
            # very old/new insightface releases may not expose this path;
            # fall back to the auto-detecting loader as a last resort.
            model = insightface.model_zoo.get_model(self._model_path)
            if not hasattr(model, "get"):
                raise RuntimeError(
                    "insightface.model_zoo.get_model() returned a raw "
                    f"{type(model).__name__} instead of a face-swap model "
                    "wrapper. This usually means the installed insightface "
                    "version can't auto-detect inswapper_128.onnx. Try "
                    "`pip install -U insightface` or reinstalling the model file."
                )
            self._model = model

        return self._model

    def swap(self, source, target, output=None):
        """
        Swap the primary face from `source` onto the primary face in `target`.

        Returns the resulting RGB numpy array, and also saves to `output`
        if a path is given.
        """
        source_face = self._detector.largest_face(source)
        if source_face is None:
            raise ValueError("No face detected in source image.")

        target_rgb = load_image_rgb(target)
        result_rgb = self.swap_cached_source(source_face, target_rgb)

        if output:
            save_image(result_rgb, output)

        return result_rgb

    def swap_cached_source(self, source_face, target):
        """
        Same swap as `swap()`, but reusing an already-detected source face
        object (as returned by `detector.largest_face()`), so callers who
        swap the same source onto many frames -- e.g. live webcam swap --
        don't need to re-run detection on the source every time.
        """
        model = self._load_model()

        target_face = self._detector.largest_face(target)
        if target_face is None:
            raise ValueError("No face detected in target image.")

        target_rgb = load_image_rgb(target)
        target_bgr = to_bgr(target_rgb)

        result_bgr = model.get(
            target_bgr,
            target_face["_raw"],
            source_face["_raw"],
            paste_back=True,
        )

        return to_rgb(result_bgr)