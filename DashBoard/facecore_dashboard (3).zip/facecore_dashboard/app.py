"""
FaceCore Dashboard — Flask backend
-----------------------------------
Wraps the FaceCore library (detect / analyze / recognize / compare / swap /
webcam) and exposes it as a JSON API. Supports switching between two engine
implementations that share the same method signatures:

    FaceCore     — insightface / onnxruntime based
    FaceCoreV22  — mediapipe + dlib + standalone onnx models based

The active engine is chosen per-request via an "engine" form field
("facecore" | "facecorev22"), or defaults to the last one selected.
Each engine is constructed lazily and cached separately, so switching
back and forth doesn't reload models unnecessarily.

Webcam support runs entirely in the browser (getUserMedia + <canvas>);
the browser captures a frame and POSTs it to /api/webcam/frame, which
runs detection/recognition/emotion on that single frame and returns
boxes + labels for the frontend to draw. This replaces the library's
original cv2.imshow-based webcam.py, which opens a native window on
whatever machine runs the Flask process and can't be shown in a browser.

Run:
    pip install -r requirements.txt
    python app.py
"""

import base64
import io
import os
import time
import traceback
import uuid

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

import numpy as np
from PIL import Image

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
GALLERY_DIR = os.path.join(BASE_DIR, "gallery")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(GALLERY_DIR, exist_ok=True)

app = Flask(__name__, static_folder="static", template_folder="templates")
CORS(app)

app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16 MB uploads

ALLOWED_EXT = {"png", "jpg", "jpeg", "webp", "bmp"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT


# ---------------------------------------------------------------------------
# Engine registry — supports FaceCore and FaceCoreV22 side by side
# ---------------------------------------------------------------------------

ENGINE_CHOICES = {
    "facecore": {
        "label": "FaceCore",
        "module": "FaceCore.core",
        "kwargs": {"ctx_id": -1},
    },
    "facecorev22": {
        "label": "FaceCoreV22",
        "module": "FaceCoreV22.core",
        "kwargs": {},
    },
}

_engines = {}        # key -> constructed Face() instance
_engine_errors = {}  # key -> error string
_active_engine_key = "facecore"


def get_engine(key=None):
    """Lazily construct and cache the Face() engine for the given key."""
    key = (key or _active_engine_key or "facecore").lower()
    if key not in ENGINE_CHOICES:
        raise RuntimeError(f"Unknown engine '{key}'. Choose one of {list(ENGINE_CHOICES)}.")

    if key in _engines:
        return _engines[key]
    if key in _engine_errors:
        raise RuntimeError(_engine_errors[key])

    spec = ENGINE_CHOICES[key]
    try:
        module = __import__(spec["module"], fromlist=["Face"])
        Face = module.Face
        engine = Face(**spec["kwargs"])
        _engines[key] = engine
        return engine
    except Exception as e:  # noqa: BLE001
        msg = (
            f"{spec['label']} engine could not be initialized "
            f"({e.__class__.__name__}: {e}). Check that its dependencies "
            "and model weights are installed."
        )
        _engine_errors[key] = msg
        raise RuntimeError(msg)


def requested_engine_key():
    """Read the 'engine' field from form data, query string, or JSON body."""
    key = request.values.get("engine")
    if not key and request.is_json:
        key = (request.get_json(silent=True) or {}).get("engine")
    return (key or _active_engine_key or "facecore").lower()


def image_from_upload(file_storage):
    """Read a werkzeug FileStorage into an RGB numpy array."""
    img = Image.open(file_storage.stream).convert("RGB")
    return np.array(img)


def image_from_b64(data_url):
    """Read a base64 data URL (from a <canvas> webcam capture) into an RGB numpy array."""
    if "," in data_url:
        data_url = data_url.split(",", 1)[1]
    raw = base64.b64decode(data_url)
    img = Image.open(io.BytesIO(raw)).convert("RGB")
    return np.array(img)


def save_preview(np_rgb, prefix="result"):
    """Save a numpy RGB image to /uploads and return its public filename."""
    fname = f"{prefix}_{uuid.uuid4().hex[:10]}.jpg"
    path = os.path.join(UPLOAD_DIR, fname)
    Image.fromarray(np_rgb).save(path, quality=92)
    return fname


def clean_faces_for_json(faces):
    """Strip non-serializable fields (_raw, embedding ndarray) from detector output."""
    if faces is None:
        return []
    single = isinstance(faces, dict)
    items = [faces] if single else faces
    cleaned = []
    for f in items:
        c = {k: v for k, v in f.items() if k not in ("_raw", "embedding")}
        if "embedding" in f and f["embedding"] is not None:
            c["embedding_dim"] = len(f["embedding"])
        cleaned.append(c)
    return cleaned


# ---------------------------------------------------------------------------
# Page routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return send_from_directory(app.template_folder, "index.html")


@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_DIR, filename)


# ---------------------------------------------------------------------------
# API: status + engine selection
# ---------------------------------------------------------------------------

@app.route("/api/engines")
def api_engines():
    """List available engines and which one is active."""
    return jsonify({
        "engines": [{"key": k, "label": v["label"]} for k, v in ENGINE_CHOICES.items()],
        "active": _active_engine_key,
    })


@app.route("/api/status")
def api_status():
    key = requested_engine_key()
    try:
        get_engine(key)
        return jsonify({"engine": "ready", "key": key, "message": f"{ENGINE_CHOICES[key]['label']} loaded."})
    except Exception as e:  # noqa: BLE001
        return jsonify({"engine": "unavailable", "key": key, "message": str(e)}), 200


@app.route("/api/engine/select", methods=["POST"])
def api_engine_select():
    """Switch the active engine for subsequent requests that don't pass one explicitly."""
    global _active_engine_key
    key = (request.form.get("engine") or (request.get_json(silent=True) or {}).get("engine") or "").lower()
    if key not in ENGINE_CHOICES:
        return jsonify({"error": f"Unknown engine '{key}'."}), 400
    _active_engine_key = key
    try:
        get_engine(key)
        return jsonify({"active": key, "ready": True})
    except Exception as e:  # noqa: BLE001
        return jsonify({"active": key, "ready": False, "message": str(e)})


# ---------------------------------------------------------------------------
# API: detect
# ---------------------------------------------------------------------------

@app.route("/api/detect", methods=["POST"])
def api_detect():
    t0 = time.time()
    try:
        if "image" not in request.files:
            return jsonify({"error": "No image file provided (field 'image')."}), 400

        f = request.files["image"]
        if f.filename == "" or not allowed_file(f.filename):
            return jsonify({"error": "Unsupported or missing file."}), 400

        img = image_from_upload(f)
        engine = get_engine(requested_engine_key())
        faces = engine.detect(img)

        return jsonify({
            "faces_found": len(faces),
            "faces": clean_faces_for_json(faces),
            "elapsed_ms": round((time.time() - t0) * 1000, 1),
        })
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 503
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify({"error": f"{e.__class__.__name__}: {e}"}), 500


# ---------------------------------------------------------------------------
# API: analyze (age / gender / emotion)
# ---------------------------------------------------------------------------

@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    t0 = time.time()
    try:
        if "image" not in request.files:
            return jsonify({"error": "No image file provided (field 'image')."}), 400

        f = request.files["image"]
        if f.filename == "" or not allowed_file(f.filename):
            return jsonify({"error": "Unsupported or missing file."}), 400

        include_emotion = request.form.get("emotion", "true").lower() != "false"

        img = image_from_upload(f)
        engine = get_engine(requested_engine_key())
        result = engine.analyze(img, include_emotion=include_emotion)

        if result is None:
            return jsonify({"error": "No face detected in the image."}), 422

        return jsonify({
            "result": result,
            "elapsed_ms": round((time.time() - t0) * 1000, 1),
        })
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 503
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify({"error": f"{e.__class__.__name__}: {e}"}), 500


# ---------------------------------------------------------------------------
# API: compare two faces
# ---------------------------------------------------------------------------

@app.route("/api/compare", methods=["POST"])
def api_compare():
    t0 = time.time()
    try:
        if "image_a" not in request.files or "image_b" not in request.files:
            return jsonify({"error": "Both 'image_a' and 'image_b' files are required."}), 400

        fa, fb = request.files["image_a"], request.files["image_b"]
        if not (allowed_file(fa.filename) and allowed_file(fb.filename)):
            return jsonify({"error": "Unsupported file type."}), 400

        img_a = image_from_upload(fa)
        img_b = image_from_upload(fb)

        engine = get_engine(requested_engine_key())
        score = engine.compare(img_a, img_b)

        return jsonify({
            "similarity": round(float(score), 2),
            "match": bool(score >= 65.0),
            "elapsed_ms": round((time.time() - t0) * 1000, 1),
        })
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 503
    except ValueError as e:
        return jsonify({"error": str(e)}), 422
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify({"error": f"{e.__class__.__name__}: {e}"}), 500


# ---------------------------------------------------------------------------
# API: recognition gallery (register / recognize / list)
# ---------------------------------------------------------------------------

@app.route("/api/gallery", methods=["GET"])
def api_gallery_list():
    try:
        engine = get_engine(requested_engine_key())
        names = list(engine._recognizer._gallery.keys())  # read-only internal peek
        return jsonify({"people": names})
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 503


@app.route("/api/gallery/register", methods=["POST"])
def api_gallery_register():
    try:
        name = request.form.get("name", "").strip()
        if not name:
            return jsonify({"error": "A 'name' field is required."}), 400
        if "image" not in request.files:
            return jsonify({"error": "No image file provided (field 'image')."}), 400

        f = request.files["image"]
        if not allowed_file(f.filename):
            return jsonify({"error": "Unsupported file type."}), 400

        img = image_from_upload(f)
        engine = get_engine(requested_engine_key())
        engine.register(name, img)

        fname = save_preview(img, prefix=f"gallery_{name}")
        return jsonify({"message": f"Registered '{name}'.", "preview": fname})
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 503
    except ValueError as e:
        return jsonify({"error": str(e)}), 422
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify({"error": f"{e.__class__.__name__}: {e}"}), 500


@app.route("/api/gallery/recognize", methods=["POST"])
def api_gallery_recognize():
    t0 = time.time()
    try:
        if "image" not in request.files:
            return jsonify({"error": "No image file provided (field 'image')."}), 400

        f = request.files["image"]
        if not allowed_file(f.filename):
            return jsonify({"error": "Unsupported file type."}), 400

        threshold = float(request.form.get("threshold", 65.0))
        img = image_from_upload(f)

        engine = get_engine(requested_engine_key())
        name = engine.recognize(img, threshold=threshold)

        return jsonify({
            "name": name,
            "elapsed_ms": round((time.time() - t0) * 1000, 1),
        })
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 503
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify({"error": f"{e.__class__.__name__}: {e}"}), 500


# ---------------------------------------------------------------------------
# API: swap
# ---------------------------------------------------------------------------

@app.route("/api/swap", methods=["POST"])
def api_swap():
    t0 = time.time()
    try:
        if "source" not in request.files or "target" not in request.files:
            return jsonify({"error": "Both 'source' and 'target' image files are required."}), 400

        src_f, tgt_f = request.files["source"], request.files["target"]
        if not (allowed_file(src_f.filename) and allowed_file(tgt_f.filename)):
            return jsonify({"error": "Unsupported file type."}), 400

        src_img = image_from_upload(src_f)
        tgt_img = image_from_upload(tgt_f)

        engine = get_engine(requested_engine_key())
        result_rgb = engine.swap(src_img, tgt_img)
        fname = save_preview(result_rgb, prefix="swap")

        return jsonify({
            "result_image": f"/uploads/{fname}",
            "elapsed_ms": round((time.time() - t0) * 1000, 1),
        })
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 503
    except ValueError as e:
        return jsonify({"error": str(e)}), 422
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify({"error": f"{e.__class__.__name__}: {e}"}), 500


# ---------------------------------------------------------------------------
# API: live webcam (browser captures frames via getUserMedia + <canvas>,
# posts each one here as a base64 JPEG; we run detect + optional recognize/
# emotion on that single frame and return boxes/labels to draw client-side)
# ---------------------------------------------------------------------------

@app.route("/api/webcam/frame", methods=["POST"])
def api_webcam_frame():
    t0 = time.time()
    try:
        payload = request.get_json(silent=True) or {}
        data_url = payload.get("image")
        if not data_url:
            return jsonify({"error": "No 'image' data URL provided."}), 400

        mode = payload.get("mode", "recognize")          # "recognize" | "emotion"
        threshold = float(payload.get("threshold", 65.0))
        engine_key = (payload.get("engine") or _active_engine_key or "facecore").lower()

        img = image_from_b64(data_url)
        engine = get_engine(engine_key)

        faces = engine.detect(img)
        out_faces = []

        # Use whichever engine's own cosine_similarity utility matches it
        cos_sim = None
        try:
            utils_mod = __import__(ENGINE_CHOICES[engine_key]["module"].rsplit(".", 1)[0] + ".utils", fromlist=["cosine_similarity"])
            cos_sim = getattr(utils_mod, "cosine_similarity", None)
        except Exception:
            cos_sim = None

        for f in faces:
            entry = {
                "bbox": f["bbox"],
                "confidence": f.get("confidence"),
                "label": None,
                "emotion": None,
            }

            if mode == "recognize":
                gallery = engine._recognizer._gallery
                if gallery and f.get("embedding") is not None and cos_sim is not None:
                    try:
                        best_name, best_score = "Unknown", -1.0
                        for name, emb in gallery.items():
                            score = cos_sim(f["embedding"], emb)
                            if score > best_score:
                                best_name, best_score = name, score
                        entry["label"] = best_name if best_score >= threshold else "Unknown"
                    except Exception:
                        entry["label"] = "Unknown"
                else:
                    entry["label"] = "Unknown"

            elif mode == "emotion":
                try:
                    emo = engine._emotion_detector.detect(img, bbox=f["bbox"])
                    if emo:
                        entry["emotion"] = emo["emotion"]
                except Exception:
                    entry["emotion"] = None

            out_faces.append(entry)

        return jsonify({
            "faces": out_faces,
            "elapsed_ms": round((time.time() - t0) * 1000, 1),
        })
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 503
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify({"error": f"{e.__class__.__name__}: {e}"}), 500


# ---------------------------------------------------------------------------
# API: live webcam face swap
#
# The source face is uploaded once and its detected face object is cached
# per engine (so we don't re-run detection on the source for every frame).
# Each incoming webcam frame is then swapped against that cached source,
# mirroring what the library's own swap_live() does with cv2.VideoCapture,
# but driven by frames the browser sends us instead of a local camera handle.
# ---------------------------------------------------------------------------

_swap_source_cache = {}  # engine_key -> (detected face dict, source RGB image)


@app.route("/api/webcam/swap_source", methods=["POST"])
def api_webcam_swap_source():
    """Upload and cache the source face used for live webcam swapping."""
    try:
        if "image" not in request.files:
            return jsonify({"error": "No image file provided (field 'image')."}), 400

        f = request.files["image"]
        if not allowed_file(f.filename):
            return jsonify({"error": "Unsupported file type."}), 400

        engine_key = requested_engine_key()
        img = image_from_upload(f)
        engine = get_engine(engine_key)

        source_face = engine._detector.largest_face(img)
        if source_face is None:
            return jsonify({"error": "No face detected in the source image."}), 422

        _swap_source_cache[engine_key] = (source_face, img)
        fname = save_preview(img, prefix="swap_source")

        return jsonify({"message": "Source face ready for live swap.", "preview": f"/uploads/{fname}"})
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 503
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify({"error": f"{e.__class__.__name__}: {e}"}), 500


@app.route("/api/webcam/swap_frame", methods=["POST"])
def api_webcam_swap_frame():
    """Swap the cached source face onto a single webcam frame and return the result image."""
    t0 = time.time()
    try:
        payload = request.get_json(silent=True) or {}
        data_url = payload.get("image")
        if not data_url:
            return jsonify({"error": "No 'image' data URL provided."}), 400

        engine_key = (payload.get("engine") or _active_engine_key or "facecore").lower()
        engine = get_engine(engine_key)

        cached = _swap_source_cache.get(engine_key)
        if cached is None:
            return jsonify({"error": "No source face registered yet. Upload one first."}), 400
        source_face, source_img = cached

        target_img = image_from_b64(data_url)

        # Route through each engine's own Swapper.swap_cached_source(), so the
        # correct model-call convention is used per engine (FaceCore's
        # insightface INSwapper.get(...) vs FaceCoreV22's raw onnxruntime
        # session.run(...) with its own alignment/embedding pipeline) instead
        # of this route hardcoding one engine's API and breaking on the other.
        try:
            result_rgb = engine._swapper.swap_cached_source(source_face, source_img, target_img)
        except TypeError:
            # FaceCore's signature is (source_face, target) — no source image needed,
            # since it uses the source face's embedding already baked into "_raw".
            result_rgb = engine._swapper.swap_cached_source(source_face, target_img)

        fname = save_preview(result_rgb, prefix="swaplive")
        return jsonify({
            "result_image": f"/uploads/{fname}",
            "face_found": True,
            "elapsed_ms": round((time.time() - t0) * 1000, 1),
        })
    except ValueError as e:
        # no face in this frame — echo the frame back untouched rather than erroring
        try:
            fname = save_preview(target_img, prefix="swaplive")
            return jsonify({
                "result_image": f"/uploads/{fname}",
                "face_found": False,
                "elapsed_ms": round((time.time() - t0) * 1000, 1),
            })
        except Exception:
            return jsonify({"error": str(e)}), 422
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 503
    except ValueError as e:
        return jsonify({"error": str(e)}), 422
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify({"error": f"{e.__class__.__name__}: {e}"}), 500


# ---------------------------------------------------------------------------

@app.errorhandler(413)
def too_large(_e):
    return jsonify({"error": "File too large. Max size is 16 MB."}), 413


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
