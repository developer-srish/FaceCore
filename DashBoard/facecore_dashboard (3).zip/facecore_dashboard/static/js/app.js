// =============================================================
// FaceCore Vision Console — frontend logic
// =============================================================

const API = "";

const state = {
  sessionId: Math.random().toString(36).slice(2, 8).toUpperCase(),
  activeEngine: "facecore",
};

document.getElementById("sessionId").textContent = state.sessionId;

// ---------------- Navigation ----------------

const panelMeta = {
  "panel-detect": { title: "Face Detection", desc: "Locate every face in an image with bounding boxes, confidence, and landmark counts." },
  "panel-analyze": { title: "Attribute Analysis", desc: "Estimate age, gender, and emotion from a detected face." },
  "panel-compare": { title: "Face Comparison", desc: "Measure similarity between two faces using embedding distance." },
  "panel-gallery": { title: "Recognition Gallery", desc: "Register known people, then identify new faces against the gallery." },
  "panel-webcam": { title: "Live Webcam", desc: "Real-time detection running on your browser's camera feed." },
  "panel-swap": { title: "Face Swap", desc: "Paste the primary face from a source image onto a target image." },
};

document.querySelectorAll(".nav-item").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    const panelId = btn.dataset.panel;
    document.getElementById(panelId).classList.add("active");
    const meta = panelMeta[panelId];
    document.getElementById("panelTitle").textContent = meta.title;
    document.getElementById("panelDesc").textContent = meta.desc;

    // stop the camera if the user navigates away from the webcam tab
    if (panelId !== "panel-webcam" && webcamRunning) {
      stopWebcam();
    }
  });
});

// ---------------- Toast ----------------

let toastTimer = null;
function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}

// ---------------- Engine switcher ----------------

const engineSwitcher = document.getElementById("engineSwitcher");
const switcherThumb = document.getElementById("switcherThumb");

engineSwitcher.querySelectorAll(".switcher-option").forEach((btn, idx) => {
  btn.addEventListener("click", async () => {
    if (btn.classList.contains("active")) return;
    engineSwitcher.querySelectorAll(".switcher-option").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    engineSwitcher.classList.toggle("pos-1", idx === 1);

    state.activeEngine = btn.dataset.engine;
    await checkStatus();
    toast(`Switched to ${btn.textContent.trim()}.`);
  });
});

// ---------------- Engine status ----------------

async function checkStatus() {
  const dot = document.getElementById("statusDot");
  const val = document.getElementById("statusValue");
  dot.className = "status-dot pending";
  val.textContent = "checking…";
  try {
    const res = await fetch(`${API}/api/status?engine=${state.activeEngine}`);
    const data = await res.json();
    if (data.engine === "ready") {
      dot.className = "status-dot ready";
      val.textContent = "Ready";
      val.title = data.message;
    } else {
      dot.className = "status-dot down";
      val.textContent = "Unavailable";
      val.title = data.message;
    }
  } catch (e) {
    dot.className = "status-dot down";
    val.textContent = "Offline";
  }
}
checkStatus();

// ---------------- Generic dropzone wiring ----------------

function wireDropzone({ zoneId, inputId, previewId, onFile }) {
  const zone = document.getElementById(zoneId);
  const input = document.getElementById(inputId);
  const preview = document.getElementById(previewId);

  zone.addEventListener("click", () => input.click());

  ["dragenter", "dragover"].forEach(evt =>
    zone.addEventListener(evt, e => { e.preventDefault(); zone.classList.add("drag-over"); })
  );
  ["dragleave", "drop"].forEach(evt =>
    zone.addEventListener(evt, e => { e.preventDefault(); zone.classList.remove("drag-over"); })
  );
  zone.addEventListener("drop", e => {
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  });
  input.addEventListener("change", () => {
    if (input.files[0]) handleFile(input.files[0]);
  });

  function handleFile(file) {
    if (!file.type.startsWith("image/")) {
      toast("Please choose an image file.");
      return;
    }
    const url = URL.createObjectURL(file);
    preview.hidden = false;
    const imgEl = preview.querySelector("img");
    if (imgEl) imgEl.src = url;
    onFile(file, url);
  }
}

// ---------------- helpers ----------------

function renderError(container, message) {
  container.innerHTML = `<div class="error-box">${escapeHtml(message)}</div>`;
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str;
  return d.innerHTML;
}

async function postForm(url, formData) {
  formData.append("engine", state.activeEngine);
  const res = await fetch(url, { method: "POST", body: formData });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data;
}

async function postJson(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...body, engine: state.activeEngine }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data;
}

// =============================================================
// PANEL 1 — DETECT
// =============================================================

let detectFile = null;

wireDropzone({
  zoneId: "dz-detect", inputId: "file-detect", previewId: "dz-detect-preview",
  onFile: (file, url) => {
    detectFile = file;
    document.getElementById("btn-detect").disabled = false;
    const img = new Image();
    img.onload = () => drawDetectCanvas(img, []);
    img.src = url;
  }
});

function drawDetectCanvas(img, faces) {
  const canvas = document.getElementById("canvas-detect");
  const maxW = 520;
  const scale = Math.min(1, maxW / img.width);
  canvas.width = img.width * scale;
  canvas.height = img.height * scale;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = "#4fd8e0";
  ctx.lineWidth = 2;
  ctx.font = "11px 'JetBrains Mono', monospace";
  faces.forEach((f, i) => {
    const [x1, y1, x2, y2] = f.bbox;
    const bx = x1 * scale, by = y1 * scale, bw = (x2 - x1) * scale, bh = (y2 - y1) * scale;
    ctx.strokeRect(bx, by, bw, bh);
    ctx.fillStyle = "#4fd8e0";
    ctx.fillRect(bx, by - 16, 62, 16);
    ctx.fillStyle = "#06181a";
    ctx.fillText(`FACE ${i + 1}`, bx + 4, by - 4);
  });
  canvas._lastImg = img;
}

document.getElementById("btn-detect").addEventListener("click", async () => {
  if (!detectFile) return;
  const resultEl = document.getElementById("detect-result");
  const elapsedEl = document.getElementById("detect-elapsed");
  const btn = document.getElementById("btn-detect");
  btn.disabled = true;
  resultEl.innerHTML = `<p class="placeholder">Running detection…</p>`;
  elapsedEl.textContent = "";

  try {
    const fd = new FormData();
    fd.append("image", detectFile);
    const data = await postForm(`${API}/api/detect`, fd);

    elapsedEl.textContent = `${data.elapsed_ms} ms`;

    const canvas = document.getElementById("canvas-detect");
    if (canvas._lastImg) drawDetectCanvas(canvas._lastImg, data.faces);

    if (data.faces_found === 0) {
      resultEl.innerHTML = `<p class="placeholder">No faces detected in this image.</p>`;
    } else {
      resultEl.innerHTML = data.faces.map((f, i) => `
        <div class="face-chip">
          <span class="fc-idx">FACE ${i + 1}</span>
          <span class="fc-meta">conf ${f.confidence} · bbox [${f.bbox.map(v => Math.round(v)).join(", ")}]${f.landmarks ? ` · ${f.landmarks.length}pt landmarks` : ""}</span>
        </div>
      `).join("");
    }
  } catch (e) {
    renderError(resultEl, e.message);
  } finally {
    btn.disabled = false;
  }
});

// =============================================================
// PANEL 2 — ANALYZE
// =============================================================

let analyzeFile = null;

wireDropzone({
  zoneId: "dz-analyze", inputId: "file-analyze", previewId: "dz-analyze-preview",
  onFile: (file) => {
    analyzeFile = file;
    document.getElementById("btn-analyze").disabled = false;
  }
});

document.getElementById("btn-analyze").addEventListener("click", async () => {
  if (!analyzeFile) return;
  const resultEl = document.getElementById("analyze-result");
  const elapsedEl = document.getElementById("analyze-elapsed");
  const btn = document.getElementById("btn-analyze");
  const includeEmotion = document.getElementById("chk-emotion").checked;

  btn.disabled = true;
  resultEl.innerHTML = `<p class="placeholder">Analyzing…</p>`;
  elapsedEl.textContent = "";

  try {
    const fd = new FormData();
    fd.append("image", analyzeFile);
    fd.append("emotion", includeEmotion);
    const data = await postForm(`${API}/api/analyze`, fd);
    elapsedEl.textContent = `${data.elapsed_ms} ms`;

    const r = Array.isArray(data.result) ? data.result[0] : data.result;

    let emotionHtml = "";
    if (r.emotion_scores) {
      const sorted = Object.entries(r.emotion_scores).sort((a, b) => b[1] - a[1]);
      emotionHtml = `<div class="emotion-bars">` + sorted.map(([name, val]) => `
        <div class="emotion-bar-row ${name === r.emotion ? "top" : ""}">
          <span>${name}</span>
          <div class="emotion-bar-track"><div class="emotion-bar-fill" style="width:${Math.round(val * 100)}%"></div></div>
          <span>${Math.round(val * 100)}%</span>
        </div>
      `).join("") + `</div>`;
    } else if (r.emotion_error) {
      emotionHtml = `<p class="note">Emotion model unavailable: ${escapeHtml(r.emotion_error)}</p>`;
    }

    resultEl.innerHTML = `
      <div class="metric-grid">
        <div class="metric"><span class="metric-label">Age</span><span class="metric-value accent">${r.age}</span></div>
        <div class="metric"><span class="metric-label">Gender</span><span class="metric-value">${r.gender}</span></div>
      </div>
      ${r.emotion ? `<div class="metric-grid" style="grid-template-columns:1fr;"><div class="metric"><span class="metric-label">Dominant emotion</span><span class="metric-value accent">${r.emotion}</span></div></div>` : ""}
      ${emotionHtml}
    `;
  } catch (e) {
    renderError(resultEl, e.message);
  } finally {
    btn.disabled = false;
  }
});

// =============================================================
// PANEL 3 — COMPARE
// =============================================================

let compareFileA = null, compareFileB = null;

function checkCompareReady() {
  document.getElementById("btn-compare").disabled = !(compareFileA && compareFileB);
}

wireDropzone({
  zoneId: "dz-compare-a", inputId: "file-compare-a", previewId: "dz-compare-a-preview",
  onFile: (file) => { compareFileA = file; checkCompareReady(); }
});
wireDropzone({
  zoneId: "dz-compare-b", inputId: "file-compare-b", previewId: "dz-compare-b-preview",
  onFile: (file) => { compareFileB = file; checkCompareReady(); }
});

document.getElementById("btn-compare").addEventListener("click", async () => {
  if (!compareFileA || !compareFileB) return;
  const resultEl = document.getElementById("compare-result");
  const elapsedEl = document.getElementById("compare-elapsed");
  const btn = document.getElementById("btn-compare");

  btn.disabled = true;
  resultEl.innerHTML = `<p class="placeholder">Comparing…</p>`;
  elapsedEl.textContent = "";

  try {
    const fd = new FormData();
    fd.append("image_a", compareFileA);
    fd.append("image_b", compareFileB);
    const data = await postForm(`${API}/api/compare`, fd);
    elapsedEl.textContent = `${data.elapsed_ms} ms`;

    resultEl.innerHTML = `
      <div class="score-display">
        <span class="score-number ${data.match ? "match" : "nomatch"}">${data.similarity}</span>
        <span class="score-label">similarity score / 100</span>
        <span class="score-verdict ${data.match ? "match" : "nomatch"}">${data.match ? "Likely same person" : "Likely different people"}</span>
      </div>
    `;
  } catch (e) {
    renderError(resultEl, e.message);
  } finally {
    btn.disabled = false;
  }
});

// =============================================================
// PANEL 4 — GALLERY
// =============================================================

let galleryFile = null, recognizeFile = null;
const registeredPeople = [];

wireDropzone({
  zoneId: "dz-gallery", inputId: "file-gallery", previewId: "dz-gallery-preview",
  onFile: (file) => {
    galleryFile = file;
    updateRegisterBtn();
  }
});

document.getElementById("gallery-name").addEventListener("input", updateRegisterBtn);
function updateRegisterBtn() {
  const name = document.getElementById("gallery-name").value.trim();
  document.getElementById("btn-register").disabled = !(name && galleryFile);
}

wireDropzone({
  zoneId: "dz-recognize", inputId: "file-recognize", previewId: "dz-recognize-preview",
  onFile: (file) => {
    recognizeFile = file;
    document.getElementById("btn-recognize").disabled = false;
  }
});

function renderGalleryGrid() {
  const grid = document.getElementById("gallery-grid");
  if (registeredPeople.length === 0) {
    grid.innerHTML = `<p class="placeholder">No one registered yet in this session.</p>`;
    return;
  }
  grid.innerHTML = registeredPeople.map(p => `
    <div class="gallery-item">
      <img src="${p.preview}" alt="${escapeHtml(p.name)}">
      <span>${escapeHtml(p.name)}</span>
    </div>
  `).join("");
}

document.getElementById("btn-register").addEventListener("click", async () => {
  const name = document.getElementById("gallery-name").value.trim();
  if (!name || !galleryFile) return;
  const btn = document.getElementById("btn-register");
  btn.disabled = true;

  try {
    const fd = new FormData();
    fd.append("name", name);
    fd.append("image", galleryFile);
    const data = await postForm(`${API}/api/gallery/register`, fd);
    registeredPeople.push({ name, preview: `/uploads/${data.preview}` });
    renderGalleryGrid();
    toast(`Registered "${name}".`);

    document.getElementById("gallery-name").value = "";
    galleryFile = null;
    document.getElementById("dz-gallery-preview").hidden = true;
  } catch (e) {
    toast(e.message);
  } finally {
    updateRegisterBtn();
  }
});

document.getElementById("btn-recognize").addEventListener("click", async () => {
  if (!recognizeFile) return;
  const out = document.getElementById("recognize-result");
  const btn = document.getElementById("btn-recognize");
  btn.disabled = true;
  out.innerHTML = `<p class="placeholder">Identifying…</p>`;

  try {
    const fd = new FormData();
    fd.append("image", recognizeFile);
    const data = await postForm(`${API}/api/gallery/recognize`, fd);
    const found = data.name && data.name !== "Unknown";
    out.innerHTML = `
      <div class="id-banner ${found ? "found" : "unknown"}">
        <div>
          <span class="metric-label">Identified as</span>
          <div class="id-name">${escapeHtml(data.name)}</div>
        </div>
      </div>
    `;
  } catch (e) {
    renderError(out, e.message);
  } finally {
    btn.disabled = false;
  }
});

// =============================================================
// PANEL 5 — WEBCAM (runs entirely via the browser's camera)
// =============================================================

let webcamStream = null;
let webcamRunning = false;
let webcamLoopHandle = null;
let webcamMode = "recognize";
let webcamSwapSourceFile = null;
let webcamSwapSourceReady = false;

const video = document.getElementById("webcam-video");
const overlay = document.getElementById("webcam-overlay");
const idleEl = document.getElementById("webcam-idle");
const recDot = document.getElementById("rec-dot");
const webcamResult = document.getElementById("webcam-result");
const webcamElapsed = document.getElementById("webcam-elapsed");
const webcamSwapControls = document.getElementById("webcam-swap-controls");
const webcamModeNote = document.getElementById("webcam-mode-note");

const modeNotes = {
  recognize: "Recognize mode matches live faces against the Gallery tab's registered people. Runs entirely through your browser's camera — no video leaves your machine except individual frames sent for analysis.",
  emotion: "Emotion mode estimates the dominant emotion for each face in the live frame.",
  swap: "Swap mode projects a source face you upload onto whatever face appears in the camera feed, frame by frame. Set a source face below before starting the camera.",
};

const webcamModeSwitcher = document.getElementById("webcamModeSwitcher");
webcamModeSwitcher.querySelectorAll(".switcher-option").forEach((btn, idx) => {
  btn.addEventListener("click", () => {
    if (btn.classList.contains("active")) return;
    webcamModeSwitcher.querySelectorAll(".switcher-option").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    webcamModeSwitcher.classList.remove("pos-1", "pos-2");
    if (idx === 1) webcamModeSwitcher.classList.add("pos-1");
    if (idx === 2) webcamModeSwitcher.classList.add("pos-2");
    webcamMode = btn.dataset.mode;

    webcamSwapControls.hidden = webcamMode !== "swap";
    webcamModeNote.textContent = modeNotes[webcamMode];

    // swap mode renders full frames as an <img>, not canvas boxes — clear whichever isn't in use
    overlay.getContext("2d").clearRect(0, 0, overlay.width, overlay.height);
    const existingImg = document.getElementById("webcam-swap-output");
    if (existingImg) existingImg.remove();
  });
});

wireDropzone({
  zoneId: "dz-webcam-swap-source", inputId: "file-webcam-swap-source", previewId: "dz-webcam-swap-source-preview",
  onFile: (file) => {
    webcamSwapSourceFile = file;
    document.getElementById("btn-webcam-swap-source").disabled = false;
  }
});

document.getElementById("btn-webcam-swap-source").addEventListener("click", async () => {
  if (!webcamSwapSourceFile) return;
  const btn = document.getElementById("btn-webcam-swap-source");
  const statusEl = document.getElementById("webcam-swap-source-status");
  btn.disabled = true;
  statusEl.textContent = "Uploading source face…";

  try {
    const fd = new FormData();
    fd.append("image", webcamSwapSourceFile);
    const data = await postForm(`${API}/api/webcam/swap_source`, fd);
    webcamSwapSourceReady = true;
    statusEl.textContent = "Source face ready — start the camera to begin swapping.";
    toast("Source face set for live swap.");
  } catch (e) {
    webcamSwapSourceReady = false;
    statusEl.textContent = "";
    renderError(document.getElementById("webcam-swap-controls"), e.message);
  } finally {
    btn.disabled = false;
  }
});

document.getElementById("btn-webcam-start").addEventListener("click", startWebcam);
document.getElementById("btn-webcam-stop").addEventListener("click", stopWebcam);

async function startWebcam() {
  try {
    webcamStream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: false });
  } catch (e) {
    toast("Could not access the camera: " + e.message);
    return;
  }
  video.srcObject = webcamStream;
  idleEl.hidden = true;
  recDot.hidden = false;
  document.getElementById("btn-webcam-start").disabled = true;
  document.getElementById("btn-webcam-stop").disabled = false;
  webcamRunning = true;
  webcamResult.innerHTML = `<p class="placeholder">Watching…</p>`;

  video.addEventListener("loadedmetadata", () => {
    overlay.width = video.videoWidth || 640;
    overlay.height = video.videoHeight || 480;
  }, { once: true });

  webcamLoop();
}

function stopWebcam() {
  webcamRunning = false;
  if (webcamLoopHandle) clearTimeout(webcamLoopHandle);
  if (webcamStream) {
    webcamStream.getTracks().forEach(t => t.stop());
    webcamStream = null;
  }
  video.srcObject = null;
  idleEl.hidden = false;
  recDot.hidden = true;
  document.getElementById("btn-webcam-start").disabled = false;
  document.getElementById("btn-webcam-stop").disabled = true;
  const ctx = overlay.getContext("2d");
  ctx.clearRect(0, 0, overlay.width, overlay.height);
  const existingImg = document.getElementById("webcam-swap-output");
  if (existingImg) existingImg.remove();
  webcamResult.innerHTML = `<p class="placeholder">Start the camera to see live detections here.</p>`;
  webcamElapsed.textContent = "";
}

const captureCanvas = document.createElement("canvas");

async function webcamLoop() {
  if (!webcamRunning) return;

  try {
    const w = video.videoWidth, h = video.videoHeight;
    if (w && h) {
      captureCanvas.width = w;
      captureCanvas.height = h;
      const cctx = captureCanvas.getContext("2d");
      // undo the CSS mirror so the frame we send matches a normal photo orientation
      cctx.translate(w, 0);
      cctx.scale(-1, 1);
      cctx.drawImage(video, 0, 0, w, h);
      const dataUrl = captureCanvas.toDataURL("image/jpeg", 0.75);

      if (webcamMode === "swap") {
        await runSwapFrame(dataUrl);
      } else {
        const data = await postJson(`${API}/api/webcam/frame`, {
          image: dataUrl,
          mode: webcamMode,
          threshold: 65.0,
        });
        webcamElapsed.textContent = `${data.elapsed_ms} ms`;
        drawWebcamOverlay(data.faces, w, h);
        renderWebcamReadout(data.faces);
      }
    }
  } catch (e) {
    renderError(webcamResult, e.message);
  }

  const delay = webcamMode === "swap" ? 900 : 700; // swap is heavier per-frame — throttle a bit more
  webcamLoopHandle = setTimeout(webcamLoop, delay);
}

async function runSwapFrame(dataUrl) {
  if (!webcamSwapSourceReady) {
    webcamResult.innerHTML = `<p class="placeholder">Set a source face above to start swapping.</p>`;
    return;
  }

  const data = await postJson(`${API}/api/webcam/swap_frame`, { image: dataUrl });
  webcamElapsed.textContent = `${data.elapsed_ms} ms`;

  // render the swapped frame in place of the raw video, over the same aspect box
  let img = document.getElementById("webcam-swap-output");
  if (!img) {
    img = document.createElement("img");
    img.id = "webcam-swap-output";
    img.className = "webcam-swap-output";
    document.querySelector(".webcam-frame").appendChild(img);
  }
  img.src = data.result_image + `?t=${Date.now()}`; // cache-bust so each frame actually updates

  webcamResult.innerHTML = data.face_found
    ? `<p class="placeholder">Swapping live — face detected in frame.</p>`
    : `<p class="placeholder">No face detected in this frame; showing camera passthrough.</p>`;
}

function drawWebcamOverlay(faces, srcW, srcH) {
  const ctx = overlay.getContext("2d");
  ctx.clearRect(0, 0, overlay.width, overlay.height);
  const scaleX = overlay.width / srcW;
  const scaleY = overlay.height / srcH;

  ctx.lineWidth = 2;
  ctx.font = "12px 'JetBrains Mono', monospace";

  faces.forEach(f => {
    const [x1, y1, x2, y2] = f.bbox;
    // mirror horizontally to match the mirrored video element
    const bx = overlay.width - (x2 * scaleX);
    const by = y1 * scaleY;
    const bw = (x2 - x1) * scaleX;
    const bh = (y2 - y1) * scaleY;

    const isKnown = f.label && f.label !== "Unknown";
    ctx.strokeStyle = isKnown ? "#f2a154" : "#4fd8e0";
    ctx.strokeRect(bx, by, bw, bh);

    const tag = f.label ? f.label : (f.emotion || "face");
    ctx.fillStyle = isKnown ? "#f2a154" : "#4fd8e0";
    const tagW = ctx.measureText(tag).width + 12;
    ctx.fillRect(bx, by - 18, tagW, 18);
    ctx.fillStyle = "#06181a";
    ctx.fillText(tag, bx + 6, by - 5);
  });
}

function renderWebcamReadout(faces) {
  if (!faces.length) {
    webcamResult.innerHTML = `<p class="placeholder">No face in frame.</p>`;
    return;
  }
  webcamResult.innerHTML = faces.map((f, i) => `
    <div class="live-face-chip">
      <span class="fc-idx">FACE ${i + 1}</span>
      <span class="fc-meta">${f.label ? f.label : ""}${f.emotion ? ` · ${f.emotion}` : ""}${f.confidence ? ` · conf ${f.confidence}` : ""}</span>
    </div>
  `).join("");
}

// =============================================================
// PANEL 6 — SWAP
// =============================================================

let swapSource = null, swapTarget = null;

function checkSwapReady() {
  document.getElementById("btn-swap").disabled = !(swapSource && swapTarget);
}

wireDropzone({
  zoneId: "dz-swap-source", inputId: "file-swap-source", previewId: "dz-swap-source-preview",
  onFile: (file) => { swapSource = file; checkSwapReady(); }
});
wireDropzone({
  zoneId: "dz-swap-target", inputId: "file-swap-target", previewId: "dz-swap-target-preview",
  onFile: (file) => { swapTarget = file; checkSwapReady(); }
});

document.getElementById("btn-swap").addEventListener("click", async () => {
  if (!swapSource || !swapTarget) return;
  const resultEl = document.getElementById("swap-result");
  const elapsedEl = document.getElementById("swap-elapsed");
  const btn = document.getElementById("btn-swap");

  btn.disabled = true;
  resultEl.innerHTML = `<p class="placeholder">Rendering swap…</p>`;
  elapsedEl.textContent = "";

  try {
    const fd = new FormData();
    fd.append("source", swapSource);
    fd.append("target", swapTarget);
    const data = await postForm(`${API}/api/swap`, fd);
    elapsedEl.textContent = `${data.elapsed_ms} ms`;
    resultEl.innerHTML = `<img class="swap-image" src="${data.result_image}" alt="Swap result">`;
  } catch (e) {
    renderError(resultEl, e.message);
  } finally {
    btn.disabled = false;
  }
});
